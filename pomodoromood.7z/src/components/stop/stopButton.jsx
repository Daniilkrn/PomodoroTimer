const StopButton = ({}) => {
    return(
        <div style={{padding:'20px 10px', backgroundColor: 'white'}}>
           Stop
        </div>
    )
} 


export default StopButton