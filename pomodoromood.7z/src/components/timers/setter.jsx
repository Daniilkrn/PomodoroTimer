// import '../../scss/timer.scss'
// import { useState, useRef } from "react"
// const Setter = ({}) => {

//     /*Refs*/
//     const plusRef = useRef()
//     const refWidth = useRef()
//     /*valueOfSetTimer*/
    

//     return(
//         <div className="set_timer">
//             <div className="selectors">
//                 <div className="plus_" onClick={increase} ref={plusRef} style={stateCorrectBtn}>
//                     <span className="plus" ></span>
//                 </div>
//                 <div className="minus_" onClick={decrease} style={stateCorrectBtn}>
//                     <span className="minus"></span>
//                 </div>
//             </div>
//             <div className="setter">
//                 <span className="toConfirm" onClick={confirmClick} style={stateCorrectBtn}>SET TIMER</span>
//                 <input type="text" style={stateCorrectBtn} onChange={(e)=>setValue(e.target.value)}/>
//                 <span className='about_setter'></span>
//             </div>
//         </div>
//     )
// } 

// export default Setter