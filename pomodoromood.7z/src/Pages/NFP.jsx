import { Link } from "react-router-dom"

const NFP = () => {
    return (
        <div className="NFP">
            <p>Not found page</p>
            <Link to='/'>Go home</Link>
        </div>
    )
}

export default NFP