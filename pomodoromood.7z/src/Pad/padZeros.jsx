export const padZero = (time) => time.toString().padStart(2,'0')
